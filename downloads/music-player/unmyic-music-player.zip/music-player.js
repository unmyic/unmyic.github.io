/**
 * 自定义网易云歌单播放器。
 * 网易云接口仅用于获取歌曲信息与音频地址，界面和播放逻辑均由本站控制。
 */
(function () {
  'use strict';

  var PLAYLIST_ID = '2791970710';
  var PLAYLIST_LIMIT = 100;
  var METING_API =
    'https://api.i-meto.com/meting/api' +
    '?server=netease&type=playlist&id=' + PLAYLIST_ID;

  var root = null;
  var audio = null;
  var tracks = [];
  var currentIndex = 0;
  var playRequested = false;
  var closeTimer = null;
  var skippedPreviewUrls = {};
  var mountObserver = null;
  var playbackMode = 'list';
  var lastAudibleVolume = 0.55;

  var PLAYBACK_MODES = {
    list: '列表循环',
    shuffle: '随机播放',
    sequential: '顺序播放',
    single: '单曲循环'
  };

  function readSetting(key) {
    try {
      return window.localStorage.getItem(key);
    } catch (error) {
      return null;
    }
  }

  function saveSetting(key, value) {
    try {
      window.localStorage.setItem(key, String(value));
    } catch (error) {
      /* 隐私模式下无法写入时，仍允许本次访问正常使用。 */
    }
  }

  function formatTime(seconds) {
    if (!Number.isFinite(seconds) || seconds < 0) return '00:00';
    var minutes = Math.floor(seconds / 60);
    var remainder = Math.floor(seconds % 60);
    return String(minutes).padStart(2, '0') + ':' +
      String(remainder).padStart(2, '0');
  }

  function normalizeTracks(rawTracks) {
    if (!Array.isArray(rawTracks)) return [];

    return rawTracks
      .slice(0, PLAYLIST_LIMIT)
      .filter(function (track) {
        return track && track.url;
      })
      .map(function (track) {
        return {
          name: track.title || '未知歌曲',
          artist: track.author || '未知歌手',
          url: track.url,
          cover: track.pic || ''
        };
      });
  }

  function createInterface() {
    root = document.createElement('div');
    root.id = 'custom-music-player';
    root.className = 'custom-music-player is-loading';
    root.innerHTML =
      '<section class="cmp-panel" aria-label="音乐播放器">' +
        '<div class="cmp-current">' +
          '<div class="cmp-cover-wrap">' +
            '<img class="cmp-cover" alt="" src="" referrerpolicy="no-referrer">' +
            '<span class="cmp-cover-fallback" aria-hidden="true">♫</span>' +
          '</div>' +
          '<div class="cmp-meta">' +
            '<div class="cmp-title">正在载入歌单</div>' +
            '<div class="cmp-artist">网易云音乐</div>' +
          '</div>' +
        '</div>' +
        '<div class="cmp-progress-row">' +
          '<span class="cmp-time-current">00:00</span>' +
          '<input class="cmp-progress" type="range" min="0" max="100" value="0" step="0.1" aria-label="播放进度">' +
          '<span class="cmp-time-total">00:00</span>' +
        '</div>' +
        '<div class="cmp-controls">' +
          '<button class="cmp-control cmp-prev" type="button" aria-label="上一首" title="上一首">‹</button>' +
          '<button class="cmp-control cmp-play" type="button" aria-label="播放" title="播放">▶</button>' +
          '<button class="cmp-control cmp-next" type="button" aria-label="下一首" title="下一首">›</button>' +
          '<button class="cmp-control cmp-list-toggle" type="button" aria-label="显示歌单" aria-expanded="false" title="歌单">☷</button>' +
        '</div>' +
        '<div class="cmp-options">' +
          '<div class="cmp-volume-control">' +
            '<button class="cmp-volume-toggle" type="button" aria-label="静音" title="静音">🔊</button>' +
            '<input class="cmp-volume" type="range" min="0" max="1" value="0.55" step="0.01" aria-label="音量">' +
          '</div>' +
          '<label class="cmp-mode-wrap">' +
            '<span class="cmp-mode-icon" aria-hidden="true">↻</span>' +
            '<select class="cmp-mode" aria-label="播放模式">' +
              '<option value="list">列表循环</option>' +
              '<option value="shuffle">随机播放</option>' +
              '<option value="sequential">顺序播放</option>' +
              '<option value="single">单曲循环</option>' +
            '</select>' +
          '</label>' +
        '</div>' +
        '<div class="cmp-status" role="status" aria-live="polite">正在连接网易云歌单…</div>' +
        '<div class="cmp-playlist" hidden>' +
          '<ol class="cmp-playlist-items"></ol>' +
        '</div>' +
      '</section>' +
      '<button class="cmp-toggle" type="button" aria-label="展开音乐播放器" aria-expanded="false" title="音乐播放器">' +
        '<span class="cmp-toggle-icon" aria-hidden="true">♫</span>' +
      '</button>';

    audio = document.createElement('audio');
    audio.preload = 'metadata';
    root.appendChild(audio);
    document.body.appendChild(root);

    var savedMode = readSetting('cmp-playback-mode');
    if (PLAYBACK_MODES[savedMode]) playbackMode = savedMode;

    var savedVolume = Number(readSetting('cmp-volume'));
    audio.volume = Number.isFinite(savedVolume) &&
      savedVolume >= 0 &&
      savedVolume <= 1
      ? savedVolume
      : 0.55;
    if (audio.volume > 0) lastAudibleVolume = audio.volume;

    root.querySelector('.cmp-mode').value = playbackMode;
    root.querySelector('.cmp-volume').value = String(audio.volume);
    updateVolumeButton();

    bindInterfaceEvents();
    bindAudioEvents();
  }

  function setOpen(open) {
    if (!root) return;
    root.classList.toggle('is-open', open);

    var toggle = root.querySelector('.cmp-toggle');
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute(
      'aria-label',
      open ? '收起音乐播放器' : '展开音乐播放器'
    );
    root.querySelector('.cmp-toggle-icon').textContent = open ? '‹' : '♫';
  }

  function setStatus(message, isError) {
    if (!root) return;
    var status = root.querySelector('.cmp-status');
    status.textContent = message || '';
    status.classList.toggle('is-error', Boolean(isError));
  }

  function updatePlayButton() {
    if (!root) return;
    var button = root.querySelector('.cmp-play');
    var playing = audio && !audio.paused;
    button.textContent = playing ? '❚❚' : '▶';
    button.setAttribute('aria-label', playing ? '暂停' : '播放');
    button.title = playing ? '暂停' : '播放';
    root.classList.toggle('is-playing', playing);
  }

  function updateVolumeButton() {
    if (!root || !audio) return;
    var button = root.querySelector('.cmp-volume-toggle');
    var effectiveVolume = audio.muted ? 0 : audio.volume;
    var icon = effectiveVolume === 0
      ? '🔇'
      : effectiveVolume < 0.5 ? '🔉' : '🔊';

    button.textContent = icon;
    button.setAttribute(
      'aria-label',
      effectiveVolume === 0 ? '恢复音量' : '静音'
    );
    button.title = effectiveVolume === 0 ? '恢复音量' : '静音';
  }

  function renderPlaylist() {
    var list = root.querySelector('.cmp-playlist-items');
    list.textContent = '';

    tracks.forEach(function (track, index) {
      var item = document.createElement('li');
      var button = document.createElement('button');
      button.type = 'button';
      button.className = 'cmp-track';
      button.dataset.index = String(index);
      button.innerHTML =
        '<span class="cmp-track-index">' + (index + 1) + '</span>' +
        '<span class="cmp-track-text">' +
          '<span class="cmp-track-title"></span>' +
          '<span class="cmp-track-artist"></span>' +
        '</span>';
      button.querySelector('.cmp-track-title').textContent = track.name;
      button.querySelector('.cmp-track-artist').textContent = track.artist;
      item.appendChild(button);
      list.appendChild(item);
    });
  }

  function updateActiveTrack() {
    if (!root) return;
    var buttons = root.querySelectorAll('.cmp-track');
    Array.prototype.forEach.call(buttons, function (button, index) {
      var active = index === currentIndex;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-current', active ? 'true' : 'false');
    });
  }

  function loadTrack(index, shouldPlay) {
    if (!tracks.length) return;

    currentIndex = (index + tracks.length) % tracks.length;
    var track = tracks[currentIndex];
    var cover = root.querySelector('.cmp-cover');

    root.querySelector('.cmp-title').textContent = track.name;
    root.querySelector('.cmp-artist').textContent = track.artist;
    cover.src = track.cover;
    cover.alt = track.name + ' 封面';
    root.classList.remove('has-cover');
    root.querySelector('.cmp-progress').value = '0';
    root.querySelector('.cmp-time-current').textContent = '00:00';
    root.querySelector('.cmp-time-total').textContent = '00:00';

    audio.src = track.url;
    audio.load();
    updateActiveTrack();
    setStatus('第 ' + (currentIndex + 1) + ' 首，共 ' + tracks.length + ' 首');

    if (shouldPlay) {
      playRequested = true;
      playCurrent();
    } else {
      updatePlayButton();
    }
  }

  function isPreviewTrack() {
    return Number.isFinite(audio.duration) &&
      audio.duration >= 28 &&
      audio.duration <= 32.5;
  }

  function skipPreviewIfNeeded() {
    var track = tracks[currentIndex];
    if (!playRequested || !track || !isPreviewTrack()) return false;
    if (skippedPreviewUrls[track.url]) return false;

    skippedPreviewUrls[track.url] = true;
    setStatus('已跳过 30 秒试听歌曲：' + track.name);
    window.setTimeout(function () {
      nextTrack(true, 'skip');
    }, 350);
    return true;
  }

  function playCurrent() {
    if (!tracks.length) return;
    playRequested = true;

    if (skipPreviewIfNeeded()) return;

    var promise = audio.play();
    if (promise && typeof promise.catch === 'function') {
      promise.catch(function () {
        setStatus('当前歌曲无法播放，正在尝试下一首…', true);
        window.setTimeout(function () {
          nextTrack(true, 'skip');
        }, 650);
      });
    }
  }

  function randomTrackIndex() {
    if (tracks.length < 2) return currentIndex;
    var nextIndex = currentIndex;
    while (nextIndex === currentIndex) {
      nextIndex = Math.floor(Math.random() * tracks.length);
    }
    return nextIndex;
  }

  function nextTrack(shouldPlay, reason) {
    reason = reason || 'manual';

    if (reason === 'ended' && playbackMode === 'single') {
      audio.currentTime = 0;
      playCurrent();
      return;
    }

    if (
      reason === 'ended' &&
      playbackMode === 'sequential' &&
      currentIndex === tracks.length - 1
    ) {
      playRequested = false;
      audio.pause();
      audio.currentTime = 0;
      updatePlayButton();
      setStatus('顺序播放已完成');
      return;
    }

    var nextIndex = playbackMode === 'shuffle'
      ? randomTrackIndex()
      : currentIndex + 1;
    loadTrack(nextIndex, shouldPlay);
  }

  function previousTrack() {
    if (audio.currentTime > 5) {
      audio.currentTime = 0;
      return;
    }
    loadTrack(currentIndex - 1, playRequested);
  }

  function togglePlaylist() {
    var playlist = root.querySelector('.cmp-playlist');
    var button = root.querySelector('.cmp-list-toggle');
    var willOpen = playlist.hidden;

    playlist.hidden = !willOpen;
    button.classList.toggle('is-active', willOpen);
    button.setAttribute('aria-expanded', String(willOpen));
    button.setAttribute('aria-label', willOpen ? '隐藏歌单' : '显示歌单');

    if (willOpen) {
      var active = root.querySelector('.cmp-track.is-active');
      if (active) active.scrollIntoView({ block: 'nearest' });
    }
  }

  function bindInterfaceEvents() {
    var toggle = root.querySelector('.cmp-toggle');

    toggle.addEventListener('click', function () {
      setOpen(!root.classList.contains('is-open'));
    });

    root.querySelector('.cmp-play').addEventListener('click', function () {
      if (!tracks.length) return;
      if (audio.paused) {
        playCurrent();
      } else {
        playRequested = false;
        audio.pause();
      }
    });

    root.querySelector('.cmp-prev').addEventListener('click', previousTrack);
    root.querySelector('.cmp-next').addEventListener('click', function () {
      nextTrack(playRequested, 'manual');
    });
    root.querySelector('.cmp-list-toggle').addEventListener('click', togglePlaylist);

    root.querySelector('.cmp-volume').addEventListener('input', function (event) {
      var volume = Number(event.target.value);
      audio.muted = false;
      audio.volume = volume;
      if (volume > 0) lastAudibleVolume = volume;
      saveSetting('cmp-volume', volume);
      updateVolumeButton();
    });

    root.querySelector('.cmp-volume-toggle').addEventListener('click', function () {
      if (audio.muted || audio.volume === 0) {
        audio.muted = false;
        audio.volume = lastAudibleVolume || 0.55;
        root.querySelector('.cmp-volume').value = String(audio.volume);
      } else {
        lastAudibleVolume = audio.volume;
        audio.muted = true;
      }
      saveSetting('cmp-volume', audio.muted ? 0 : audio.volume);
      updateVolumeButton();
    });

    root.querySelector('.cmp-mode').addEventListener('change', function (event) {
      var selectedMode = event.target.value;
      if (!PLAYBACK_MODES[selectedMode]) return;
      playbackMode = selectedMode;
      saveSetting('cmp-playback-mode', playbackMode);
      setStatus('播放模式：' + PLAYBACK_MODES[playbackMode]);
    });

    root.querySelector('.cmp-progress').addEventListener('input', function (event) {
      if (!Number.isFinite(audio.duration)) return;
      audio.currentTime = audio.duration * (Number(event.target.value) / 100);
    });

    root.querySelector('.cmp-playlist-items').addEventListener('click', function (event) {
      var button = event.target.closest('.cmp-track');
      if (!button) return;
      loadTrack(Number(button.dataset.index), true);
    });

    var cover = root.querySelector('.cmp-cover');
    cover.addEventListener('load', function () {
      root.classList.add('has-cover');
    });
    cover.addEventListener('error', function () {
      root.classList.remove('has-cover');
    });

    if (window.matchMedia('(hover: hover) and (pointer: fine)').matches) {
      root.addEventListener('mouseenter', function () {
        window.clearTimeout(closeTimer);
        setOpen(true);
      });
      root.addEventListener('mouseleave', function () {
        closeTimer = window.setTimeout(function () {
          setOpen(false);
        }, 500);
      });
    }
  }

  function bindAudioEvents() {
    audio.addEventListener('play', updatePlayButton);
    audio.addEventListener('pause', updatePlayButton);
    audio.addEventListener('ended', function () {
      nextTrack(true, 'ended');
    });
    audio.addEventListener('loadedmetadata', function () {
      root.querySelector('.cmp-time-total').textContent =
        formatTime(audio.duration);
      skipPreviewIfNeeded();
    });
    audio.addEventListener('timeupdate', function () {
      var ratio = Number.isFinite(audio.duration) && audio.duration > 0
        ? (audio.currentTime / audio.duration) * 100
        : 0;
      root.querySelector('.cmp-progress').value = String(ratio);
      root.querySelector('.cmp-time-current').textContent =
        formatTime(audio.currentTime);
    });
    audio.addEventListener('error', function () {
      if (!playRequested) {
        setStatus('当前歌曲暂时无法播放', true);
        return;
      }
      setStatus('当前歌曲不可用，正在跳到下一首…', true);
      window.setTimeout(function () {
        nextTrack(true, 'skip');
      }, 650);
    });
  }

  function loadPlaylist() {
    window.fetch(METING_API, { mode: 'cors' })
      .then(function (response) {
        if (!response.ok) {
          throw new Error('Playlist request failed: ' + response.status);
        }
        return response.json();
      })
      .then(function (data) {
        tracks = normalizeTracks(data);
        if (!tracks.length) throw new Error('No playable tracks returned');

        renderPlaylist();
        root.classList.remove('is-loading');
        root.classList.add('is-ready');
        loadTrack(0, false);
      })
      .catch(function (error) {
        root.classList.remove('is-loading');
        root.classList.add('has-error');
        root.querySelector('.cmp-title').textContent = '歌单加载失败';
        root.querySelector('.cmp-artist').textContent = '请稍后重试';
        setStatus('无法连接网易云歌单', true);
        console.error('[custom-music-player]', error);
      });
  }

  function initialize() {
    var existing = document.getElementById('custom-music-player');
    if (existing) {
      root = existing;
      audio = existing.querySelector('audio');
      return;
    }
    createInterface();
    loadPlaylist();
  }

  function ensurePlayerMounted() {
    if (!document.body) return;

    if (!root) {
      initialize();
      return;
    }

    if (!root.isConnected || root.parentElement !== document.body) {
      document.body.appendChild(root);
    }

    root.hidden = false;
    root.setAttribute('data-current-page', window.location.pathname);
  }

  function handlePageReady() {
    window.requestAnimationFrame(function () {
      ensurePlayerMounted();
    });
  }

  function observePlayerMount() {
    if (mountObserver || !document.body) return;
    mountObserver = new MutationObserver(function () {
      if (root && !root.isConnected) ensurePlayerMounted();
    });
    mountObserver.observe(document.body, { childList: true });
  }

  document.addEventListener('pjax:complete', handlePageReady);
  window.addEventListener('pageshow', handlePageReady);

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      initialize();
      observePlayerMount();
    });
  } else {
    initialize();
    observePlayerMount();
  }

  window.__unmyicMusicPlayer = {
    ensureMounted: ensurePlayerMounted,
    open: function () { setOpen(true); },
    close: function () { setOpen(false); }
  };
})();
