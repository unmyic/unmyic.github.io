Unmyic Blog Music Player
=========================

这是本站左下角悬浮音乐播放器的源码快照。

文件：
- music-player.js：播放器界面、歌单请求与播放控制
- music-player.css：亮色/暗色、展开动画与移动端样式
- butterfly-inject.yml：Hexo Butterfly 主题的注入示例

快速使用（Hexo + Butterfly）：
1. 将 music-player.js 复制到 source/js/
2. 将 music-player.css 复制到 source/css/
3. 修改 music-player.js 顶部的 PLAYLIST_ID
4. 将 butterfly-inject.yml 中的配置合并进 _config.butterfly.yml
5. 运行 npm run clean、npm run build、npm run server

普通网页：
在页面 head 中引入 CSS，在 body 结束前引入带 defer 的 JS。
脚本会自动创建播放器，不需要额外的 HTML 容器。

说明：
- 组件不是 Hexo 专属，核心使用原生 HTML/CSS/JavaScript 与 Audio API。
- 当前歌单数据来自第三方 Meting 兼容接口，不能保证永久可用。
- 网易云 VIP 登录态不会传递给博客中的原生 Audio。
- 请仅使用拥有版权、得到授权或平台允许公开播放的音乐。
- 浏览器通常要求用户先进行一次点击，才允许播放有声媒体。

教程：
部署后访问 /2026/07/27/custom-music-player-guide/
