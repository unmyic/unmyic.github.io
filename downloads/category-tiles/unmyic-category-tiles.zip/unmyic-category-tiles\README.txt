unmyic-category-tiles
=====================

一个将 Hexo Butterfly 分类文字列表增强为全息磁贴的原生 CSS/JavaScript 组件。

文件：
- category-tiles.css：磁贴布局、明暗主题、响应式和全息高光
- category-tiles.js：读取分类 DOM、生成磁贴、自动配色及指针倾斜
- butterfly-inject.yml：Butterfly 注入示例

安装：
1. 将 CSS 复制到 source/css/category-tiles.css
2. 将 JS 复制到 source/js/category-tiles.js
3. 把 butterfly-inject.yml 中两行资源加入 _config.butterfly.yml
4. 执行 npm run clean && npm run build

脚本默认适配 Butterfly 的 /categories/ 页面，同时支持 PJAX。
