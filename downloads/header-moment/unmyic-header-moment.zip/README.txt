Unmyic Header Moment
====================

一个使用原生 JavaScript 和 CSS 编写的页首时光状态组件。

功能：
- 访客本地实时时钟
- 日期与星期
- 时段问候和图标
- 今日进度
- 移动端适配
- PJAX 页面切换恢复

Hexo + Butterfly：
1. 将 clock.js 放入 source/js/
2. 将 clock.css 放入 source/css/
3. 把 butterfly-inject.yml 中的配置合并到 _config.butterfly.yml
4. 运行 npm run clean、npm run build、npm run server

普通网页：
页面中需要一个 id="site-info" 的挂载容器，然后引入 CSS 和 JS。
也可以修改 clock.js 中的选择器，将组件挂到侧栏、导航栏或页脚。

本组件不读取定位、不请求天气接口，也不是 Hexo 专属。
